package com.arto.arto.domain.inquiries.type;

public enum InquiryStatus {
    PENDING,        // 대기
    ANSWERED        // 답변완료
}
