package com.arto.arto.domain.artwork_images.type;

public enum ImageType {
    MAIN,       // 메인
    DETAIL,     // 상세
    THUMBNAIL   // 썸네일
}
