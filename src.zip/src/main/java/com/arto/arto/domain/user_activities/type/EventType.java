package com.arto.arto.domain.user_activities.type;

public enum EventType {
    PAGE_VIEW,
    LOGIN,
    LOGOUT,
    CLICK,
    SEARCH
    // 필요에 따라 다른 활동 유형 추가
}
