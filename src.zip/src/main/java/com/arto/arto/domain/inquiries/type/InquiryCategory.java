package com.arto.arto.domain.inquiries.type;

public enum InquiryCategory {
    SHIPPING,       // 배송
    PRODUCT_ISSUE   // 상품문제
}
