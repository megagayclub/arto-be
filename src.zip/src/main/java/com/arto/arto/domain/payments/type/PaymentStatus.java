package com.arto.arto.domain.payments.type;

public enum PaymentStatus {
    PENDING,        // 미결제
    CONFIRMED       // 결제확인
}
