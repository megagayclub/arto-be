package com.arto.arto.domain.artwork.type;

public enum Mood {
    NORDIC,          // 북유럽
    MODERN_CHIC,     // 모던시크
    VINTAGE,         // 빈티지
    MINIMAL,         // 미니멀
    MODERN_CLASSIC,  // 모던클래식
    INDUSTRIAL       // 인더스트리얼
}
