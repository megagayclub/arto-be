package com.arto.arto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArtoApplicationTests {

	@Test
	void contextLoads() {
	}

}
